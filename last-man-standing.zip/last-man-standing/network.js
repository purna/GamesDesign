import { joinRoom, selfId } from 'https://esm.sh/trystero@0.22.0/nostr';
import {
  APP_ID,
  RELAY_URLS,
  TURN_SERVERS,
  MAX_PLAYERS,
  GAME_STATE,
  GAME_OVER_DELAY_MS,
  PODIUM_SECONDS,
  HOST_ASSIGNMENT_DELAY_MS,
  BUCKET_MS,
  TILE
} from './config.js';
import { state, freshItems, freshEnemies } from './state.js';
import { roomNameFor } from './time.js';
import { electRoundHost, electFailoverHost, resolveHostConflict } from './host.js';
import { validateNameFormat } from './username.js';
import {
  resetLocalRoundState,
  pickFreeSpawnIndex,
  broadcastMe,
  myStatePayload,
  processPickup,
  startGame,
  showGameScreen,
  showPodiumScreen,
  refreshSpectatorBanner,
  updateLobby,
  setSpectator,
  applyEnemyDamage
} from './game.js';

const JOIN_GRACE_MS = 1500;
const NO_PEERS_WARN_MS = 12000;

function isLateArrival(startedAt) {
  return !!startedAt && !!state.joinedRoomAt && startedAt < state.joinedRoomAt - JOIN_GRACE_MS;
}

/**
 * Tracks whether any peer has been seen since the last (re)connect, so the
 * lobby can surface a "nobody here yet" state instead of looking like an
 * empty room with no explanation. Reset on every connectToRoom call.
 */
export function notePeerSeen() {
  state.lastPeerSeenAt = Date.now();
}

export function noPeersSeenForMs() {
  return state.lastPeerSeenAt ? Date.now() - state.lastPeerSeenAt : Date.now() - state.joinedRoomAt;
}

function markLateArrival() {
  setSpectator(true, 'Match in progress — you join the next arena');
  state.me.alive = false;
  document.getElementById('game-in-progress-overlay').classList.remove('hidden');
  if (state.sendPlayerState) state.sendPlayerState(myStatePayload());
}

function rosterIds() {
  return Object.keys(state.peers).filter(id => state.peers[id] && state.peers[id].name);
}

/**
 * Resolves the "two clients both think they are host" case. Every client runs
 * the same election over the same union roster, so whichever one is not the
 * elected id stands down and says so. Called whenever a host claim arrives and
 * once per game tick as a safety net.
 */
export function reconcileHost() {
  if (!state.room || state.activeBucket === null) return;
  const ids = rosterIds();
  const claimants = ids.filter(id => state.peers[id].isHost);
  const allClaimants = claimants.concat(state.isHostFlag ? [state.selfId] : []);
  if (allClaimants.length <= 1) {
    state.hostId = allClaimants[0] || state.hostId;
    return;
  }
  const elected = electHost(allClaimants, state.activeBucket + state.failoverSeq);
  state.hostId = elected;
  if (state.isHostFlag && elected !== state.selfId) {
    state.isHostFlag = false;
    if (state.sendAnnounce) state.sendAnnounce({ name: state.myName, isHost: false });
    updateLobby();
  }
  ids.forEach(id => {
    if (state.peers[id].isHost && id !== elected) state.peers[id].isHost = false;
  });
}

export function connectToRoom(bucket) {
  // Re-check the stored name on every (re)connect, so a name can never reach
  // the wire without passing the format rule.
  const nameCheck = validateNameFormat(state.myName);
  if (!nameCheck.ok) {
    console.warn('Refusing to join with an invalid name:', nameCheck.reason);
    return;
  }
  state.myName = nameCheck.name;

  if (state.room) {
    try { state.room.leave(); } catch (error) {}
  }

  state.peers = {};
  state.lastHostId = state.hostId;
  state.hostId = null;
  state.failoverSeq = 0;
  state.roundId = bucket;
  state.activeBucket = bucket;
  state.activeBucketStartMs = bucket * BUCKET_MS;
  state.isHostFlag = false;
  state.nextEnemySpawnAt = 0;
  state.enemySpawnSeq = 0;
  state.hostAssignedRooms = {};
  state.selfId = selfId;
  state.forcedWinner = null;
  state.podiumStartedAt = 0;
  state.gameEndAt = 0;
  state.winnerAnnouncedAt = null;
  state.pendingRejoin = false;
  state.joinedRoomAt = Date.now();

  const room = joinRoom({ appId: APP_ID, relayUrls: RELAY_URLS, rtcConfig: { iceServers: TURN_SERVERS } }, roomNameFor(bucket));
  state.room = room;

  const [sendAnnounce, getAnnounce] = room.makeAction('announce');
  const [sendPlayerState, getPlayerState] = room.makeAction('pstate');
  const [sendWorldState, getWorldState] = room.makeAction('wstate');
  const [sendPickup, getPickup] = room.makeAction('pickup');
  const [sendEnemyHit, getEnemyHit] = room.makeAction('enemyHit');
  const [sendReject, getReject] = room.makeAction('reject');
  const [sendStartGame, getStartGame] = room.makeAction('start');
  const [sendAssign, getAssign] = room.makeAction('assign');
  const [sendGameState, getGameState] = room.makeAction('gamestate');

  state.sendAnnounce = sendAnnounce;
  state.sendPlayerState = sendPlayerState;
  state.sendWorldState = sendWorldState;
  state.sendPickup = sendPickup;
  state.sendEnemyHit = sendEnemyHit;
  state.sendStartGame = sendStartGame;
  state.sendAssign = sendAssign;
  state.sendGameState = sendGameState;
  state.manualStartTriggered = false;

  getStartGame(() => {
    state.manualStartTriggered = true;
    if (state.isHostFlag) startGame();
  });

  getGameState(data => {
    if (!data || !data.state) return;
    if (data.state === GAME_STATE.IN_GAME) {
      state.gameState = GAME_STATE.IN_GAME;
      state.gameStartedAt = data.startedAt || Date.now();
      showGameScreen();
      if (isLateArrival(state.gameStartedAt)) {
        // The match was already running when this client joined the room, so it
        // watches rather than playing: no spawn, no damage, not in the roster.
        markLateArrival();
      } else {
        document.getElementById('game-in-progress-overlay').classList.add('hidden');
      }
    } else if (data.state === GAME_STATE.PODIUM) {
      state.gameState = GAME_STATE.PODIUM;
      state.forcedWinner = data.winner || state.forcedWinner || null;
      if (data.host) state.lastHostId = data.host;
      state.gameEndAt = data.endsAt || (Date.now() + (PODIUM_SECONDS * 1000));
      if (data.nextHost) state.nextHostHint = data.nextHost;
      showPodiumScreen(state.forcedWinner);
    } else if (data.state === GAME_STATE.GAME_OVER) {
      state.gameState = GAME_STATE.PODIUM;
      state.forcedWinner = data.winner || state.forcedWinner || null;
      if (data.host) state.lastHostId = data.host;
      state.gameEndAt = (data.endsAt || Date.now()) + GAME_OVER_DELAY_MS;
      if (data.nextHost) state.nextHostHint = data.nextHost;
      showPodiumScreen(state.forcedWinner);
    }
  });

  getAnnounce((data, peerId) => {
    // Peers police each other: a malformed or rejected name is simply ignored.
    if (!data || !validateNameFormat(data.name).ok) return;
    notePeerSeen();
    state.peers[peerId] = state.peers[peerId] || {};
    if (state.peers[peerId].joinIndex === undefined) {
      state.peers[peerId].joinIndex = Object.keys(state.peers).filter(id => state.peers[id].joinIndex !== undefined).length;
    }
    state.peers[peerId].name = data.name;
    state.peers[peerId].isHost = !!data.isHost;
    if (data.isHost) {
      state.hostId = peerId;
      reconcileHost();
    } else if (state.hostId === peerId) {
      state.hostId = state.isHostFlag ? state.selfId : null;
    }
    if (state.isHostFlag && state.gameState !== GAME_STATE.IN_GAME && state.hostAssignedRooms[peerId] === undefined) {
      const spawnIndex = pickFreeSpawnIndex();
      state.hostAssignedRooms[peerId] = spawnIndex;
      sendAssign({ spawnIndex }, peerId);
    }
  });

  getAssign(data => {
    if (data && typeof data.spawnIndex === 'number') {
      resetLocalRoundState(data.spawnIndex);
      broadcastMe();
    }
  });

  getPlayerState((data, peerId) => {
    if (data && data.name !== undefined && !validateNameFormat(data.name).ok) return;
    state.peers[peerId] = state.peers[peerId] || {};
    Object.assign(state.peers[peerId], data);
  });

  getWorldState(data => {
    if (data.items) state.items = data.items;
    if (data.enemies) {
      state.enemies = data.enemies.map(enemy => {
        const previous = state.enemies.find(candidate => candidate.id === enemy.id);
        const roomKey = `${enemy.roomRow},${enemy.roomCol}`;
        const sameRoom = previous && previous._roomKey === roomKey;
        return {
          ...enemy,
          _roomKey: roomKey,
          health: enemy.health,
          maxHealth: enemy.maxHealth,
          lastHitAt: enemy.lastHitAt,
          diedAt: enemy.diedAt,
          renderX: sameRoom ? previous.renderX : enemy.x * TILE,
          renderY: sameRoom ? previous.renderY : enemy.y * TILE
        };
      });
    }
  });

  getEnemyHit((data, peerId) => {
    if (state.isHostFlag && data && data.enemyId) applyEnemyDamage(data.enemyId, 1);
  });

  getPickup((data, peerId) => {
    if (state.isHostFlag) processPickup(data.itemId, peerId);
  });

  getReject(data => {
    setSpectator(true, (data && data.reason) || 'Arena is full — spectating until next round');
    state.me.alive = false;
    if (state.sendPlayerState) state.sendPlayerState(myStatePayload());
    refreshSpectatorBanner();
  });

  room.onPeerJoin(peerId => {
    const currentCount = Object.keys(state.peers).filter(id => state.peers[id] && state.peers[id].name).length + 1;
    if (state.isHostFlag && currentCount > MAX_PLAYERS) {
      sendReject({ reason: `Arena is full! Maximum ${MAX_PLAYERS} players.` }, peerId);
      return;
    }
    if (state.isHostFlag && state.gameState === GAME_STATE.IN_GAME) {
      // Authoritative side of the late-arrival rule: the host tells the newcomer
      // to spectate, and never assigns it a spawn room.
      sendReject({ reason: 'Match in progress — you join the next arena' }, peerId);
      sendGameState({ state: GAME_STATE.IN_GAME, startedAt: state.gameStartedAt }, peerId);
      return;
    }
    sendAnnounce({ name: state.myName, isHost: state.isHostFlag });
    sendPlayerState(myStatePayload());
  });

  room.onPeerLeave(peerId => {
    const departedWasHost = !!(state.peers[peerId] && state.peers[peerId].isHost) || state.hostId === peerId;
    delete state.peers[peerId];
    const activeIds = Object.keys(state.peers).filter(id => state.peers[id] && state.peers[id].name);
    const hostExists = activeIds.some(id => state.peers[id].isHost);
    if (hostExists || !departedWasHost) return;

    // Deterministic failover: every remaining client runs the same election on
    // the same roster, so exactly one of them promotes itself. World state is
    // left alone, so a mid-round failover does not reset the match.
    state.failoverSeq += 1;
    state.lastHostId = peerId;
    const elected = electFailoverHost(activeIds.concat([selfId]), bucket, peerId, state.failoverSeq);
    state.hostId = elected;
    state.isHostFlag = elected === selfId;
    if (state.isHostFlag) {
      if (state.gameState !== GAME_STATE.IN_GAME) {
        state.items = freshItems();
        state.enemies = freshEnemies();
      }
      sendAnnounce({ name: state.myName, isHost: true });
      sendPlayerState(myStatePayload());
    }
    updateLobby();
  });

  state.isSpectator = false;
  state.gameState = GAME_STATE.WAITING;
  resetLocalRoundState(0);

  setTimeout(() => {
    const activeIds = Object.keys(state.peers).filter(id => state.peers[id] && state.peers[id].name);
    const hostAlreadyClaimed = activeIds.some(id => state.peers[id].isHost);
    if (hostAlreadyClaimed) {
      state.hostId = activeIds.find(id => state.peers[id].isHost) || state.hostId;
      state.isHostFlag = false;
    } else if (state.nextHostHint && (state.nextHostHint === selfId || activeIds.includes(state.nextHostHint))) {
      // The previous round nominated who runs this one.
      state.hostId = state.nextHostHint;
      state.isHostFlag = state.nextHostHint === selfId;
      state.nextHostHint = null;
    } else {
      // No usable nomination (first arena, or the nominee did not come back):
      // fall back to the deterministic election keyed on the arena bucket.
      state.nextHostHint = null;
      const elected = electRoundHost(activeIds.concat([selfId]), bucket, state.lastHostId);
      state.hostId = elected;
      state.isHostFlag = elected === selfId;
    }
    if (state.isHostFlag) {
      state.items = freshItems();
      state.enemies = freshEnemies();
      state.nextEnemySpawnAt = 0;
      state.enemySpawnSeq = 0;
      const mySpawnIndex = pickFreeSpawnIndex(true);
      state.hostAssignedRooms[selfId] = mySpawnIndex;
      resetLocalRoundState(mySpawnIndex);
      activeIds.forEach(id => {
        if (state.hostAssignedRooms[id] === undefined) {
          const spawnIndex = pickFreeSpawnIndex();
          state.hostAssignedRooms[id] = spawnIndex;
          sendAssign({ spawnIndex }, id);
        }
      });
    }
    sendAnnounce({ name: state.myName, isHost: state.isHostFlag });
    sendPlayerState(myStatePayload());
    refreshSpectatorBanner();
    updateLobby();
  }, HOST_ASSIGNMENT_DELAY_MS);
}
